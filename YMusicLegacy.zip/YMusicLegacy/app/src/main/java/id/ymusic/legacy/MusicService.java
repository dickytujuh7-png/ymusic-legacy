package id.ymusic.legacy;

import android.app.*;
import android.content.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
import java.io.IOException;

public class MusicService extends Service implements MediaPlayer.OnPreparedListener,
        MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener {
    private final IBinder binder = new LocalBinder();
    private MediaPlayer player;
    private String status = "Siap memutar";
    private static final int NOTIFICATION_ID = 1001;

    public class LocalBinder extends Binder {
        MusicService getService() { return MusicService.this; }
    }

    @Override public IBinder onBind(Intent intent) { return binder; }

    @Override public void onCreate() {
        super.onCreate();
        createPlayer();
    }

    private void createPlayer() {
        releasePlayer();
        player = new MediaPlayer();
        player.setAudioStreamType(AudioManager.STREAM_MUSIC);
        player.setOnPreparedListener(this);
        player.setOnCompletionListener(this);
        player.setOnErrorListener(this);
    }

    public void playUrl(String url) {
        playSource(null, url);
    }

    public void playLocal(Uri uri) {
        playSource(uri, null);
    }

    private void playSource(Uri uri, String url) {
        try {
            createPlayer();
            status = "Memuat audio…";
            if (uri != null) player.setDataSource(this, uri);
            else player.setDataSource(url);
            player.prepareAsync();
            startForeground(NOTIFICATION_ID, makeNotification("Memuat audio"));
        } catch (IOException | IllegalArgumentException e) {
            status = "Gagal membuka sumber audio";
            stopForeground(true);
        } catch (SecurityException e) {
            status = "Akses audio ditolak";
            stopForeground(true);
        }
    }

    @Override public void onPrepared(MediaPlayer mp) {
        if (mp != player) return;
        try {
            mp.start();
            status = "Sedang diputar";
            startForeground(NOTIFICATION_ID, makeNotification("YMusic Legacy sedang memutar audio"));
        } catch (IllegalStateException e) {
            status = "Tidak dapat memulai pemutaran";
        }
    }

    public void pause() {
        if (player != null && player.isPlaying()) {
            player.pause(); status = "Dijeda";
            startForeground(NOTIFICATION_ID, makeNotification("Pemutaran dijeda"));
        }
    }

    public void resume() {
        if (player != null) {
            try { player.start(); status = "Sedang diputar"; }
            catch (IllegalStateException e) { status = "Tidak ada audio siap diputar"; }
        }
    }

    public String getStatus() { return status; }

    @Override public void onCompletion(MediaPlayer mp) {
        status = "Pemutaran selesai";
        stopForeground(true);
        stopSelf();
    }

    @Override public boolean onError(MediaPlayer mp, int what, int extra) {
        status = "Format audio tidak didukung atau stream terputus";
        stopForeground(true);
        return true;
    }

    private Notification makeNotification(String text) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel channel = new NotificationChannel("ymusic_playback",
                    "Pemutaran musik", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(channel);
            return new Notification.Builder(this, "ymusic_playback")
                    .setContentTitle("YMusic Legacy").setContentText(text)
                    .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build();
        }
        return new Notification.Builder(this).setContentTitle("YMusic Legacy")
                .setContentText(text).setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true).build();
    }

    private void releasePlayer() {
        if (player != null) {
            try { player.reset(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
    }

    @Override public void onDestroy() {
        releasePlayer();
        stopForeground(true);
        super.onDestroy();
    }
}
