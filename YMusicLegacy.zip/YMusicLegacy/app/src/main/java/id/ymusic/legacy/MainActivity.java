
package id.ymusic.legacy;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.Manifest;
import android.content.Intent;
import android.content.Context;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.IBinder;
import android.provider.MediaStore;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;

public class MainActivity extends Activity {

    private MusicService music;
    private boolean bound = false;

    private TextView statusText;
    private ListView songList;
    private EditText urlInput;

    private ArrayList<Song> songs = new ArrayList<Song>();

    private int bgColor = Color.rgb(17, 19, 28);
    private int cardColor = Color.rgb(29, 33, 46);
    private int accentColor = Color.rgb(0, 190, 160);

    private class Song {
        String title;
        String artist;
        Uri uri;

        Song(String t, String a, Uri u) {
            title = t;
            artist = a;
            uri = u;
        }

        public String toString() {
            return title + "\n" + artist;
        }
    }

    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.LocalBinder binder =
                    (MusicService.LocalBinder) service;
            music = binder.getService();
            bound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            bound = false;
            music = null;
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(bgColor);
        getWindow().setNavigationBarColor(bgColor);

        buildHome();

        Intent serviceIntent =
                new Intent(MainActivity.this, MusicService.class);

        startService(serviceIntent);
        bindService(serviceIntent, connection, Context.BIND_AUTO_CREATE);

        checkPermission();
    }

    private void buildHome() {

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(12));
        root.setBackgroundColor(bgColor);

        TextView brand = new TextView(this);
        brand.setText("YMusic");
        brand.setTextSize(30);
        brand.setTextColor(Color.WHITE);
        brand.setTypeface(null, Typeface.BOLD);

        root.addView(brand);

        TextView subtitle = new TextView(this);
        subtitle.setText("LEGACY MUSIC PLAYER");
        subtitle.setTextSize(11);
        subtitle.setTextColor(accentColor);
        subtitle.setPadding(0, dp(3), 0, dp(18));

        root.addView(subtitle);

        LinearLayout playerCard = new LinearLayout(this);
        playerCard.setOrientation(LinearLayout.VERTICAL);
        playerCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        playerCard.setBackground(round(cardColor, 18));

        TextView nowPlaying = new TextView(this);
        nowPlaying.setText("SEDANG DIPUTAR");
        nowPlaying.setTextColor(accentColor);
        nowPlaying.setTextSize(11);

        playerCard.addView(nowPlaying);

        TextView playerTitle = new TextView(this);
        playerTitle.setText("Nikmati musik favoritmu");
        playerTitle.setTextColor(Color.WHITE);
        playerTitle.setTextSize(18);
        playerTitle.setTypeface(null, Typeface.BOLD);
        playerTitle.setPadding(0, dp(10), 0, dp(14));

        playerCard.addView(playerTitle);

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        controls.setOrientation(LinearLayout.HORIZONTAL);

        Button pauseButton = makeButton("PAUSE");
        Button resumeButton = makeButton("RESUME");

        controls.addView(pauseButton,
                new LinearLayout.LayoutParams(0, dp(45), 1));

        controls.addView(resumeButton,
                new LinearLayout.LayoutParams(0, dp(45), 1));

        playerCard.addView(controls);
        root.addView(playerCard);

        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (music != null) {
                    music.pause();
                    updateStatus();
                }
            }
        });

        resumeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (music != null) {
                    music.resume();
                    updateStatus();
                }
            }
        });

        statusText = new TextView(this);
        statusText.setText("Status: Siap memutar");
        statusText.setTextColor(Color.LTGRAY);
        statusText.setTextSize(12);
        statusText.setPadding(0, dp(12), 0, dp(12));

        root.addView(statusText);

        TextView libraryTitle = new TextView(this);
        libraryTitle.setText("Perpustakaan Musik");
        libraryTitle.setTextSize(19);
        libraryTitle.setTextColor(Color.WHITE);
        libraryTitle.setTypeface(null, Typeface.BOLD);

        root.addView(libraryTitle);

        songList = new ListView(this);
        songList.setDividerHeight(dp(1));
        songList.setDivider(new android.graphics.drawable.ColorDrawable(
                cardColor));
        songList.setBackgroundColor(bgColor);

        root.addView(songList,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        songList.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent,
                                    View view, int position, long id) {
                if (bound && music != null) {
                    Song song = songs.get(position);
                    music.playLocal(song.uri);
                    updateStatus();
                } else {
                    Toast.makeText(MainActivity.this,
                            "Layanan musik sedang disiapkan",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        TextView onlineTitle = new TextView(this);
        onlineTitle.setText("Putar dari URL");
        onlineTitle.setTextColor(Color.WHITE);
        onlineTitle.setTextSize(16);
        onlineTitle.setTypeface(null, Typeface.BOLD);
        onlineTitle.setPadding(0, dp(12), 0, dp(6));

        root.addView(onlineTitle);

        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setTextColor(Color.WHITE);
        urlInput.setHintTextColor(Color.GRAY);
        urlInput.setHint("Masukkan URL audio");
        urlInput.setTextSize(14);
        urlInput.setPadding(dp(12), 0, dp(12), 0);
        urlInput.setBackground(round(cardColor, 10));

        root.addView(urlInput,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, dp(48)));

        Button playUrlButton = makeButton("PUTAR URL");
        LinearLayout.LayoutParams urlParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, dp(45));
        urlParams.topMargin = dp(8);

        root.addView(playUrlButton, urlParams);

        playUrlButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = urlInput.getText().toString().trim();

                if (url.length() == 0) {
                    Toast.makeText(MainActivity.this,
                            "Masukkan URL audio terlebih dahulu",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                if (bound && music != null) {
                    music.playUrl(url);
                    updateStatus();
                }
            }
        });

        setContentView(root);
    }

    private void checkPermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(
                    Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {

                requestPermissions(
                        new String[] {
                            Manifest.permission.READ_EXTERNAL_STORAGE
                        }, 41);
                return;
            }
        }

        loadSongs();
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, String[] permissions, int[] results) {

        super.onRequestPermissionsResult(
                requestCode, permissions, results);

        if (requestCode == 41) {
            if (results.length > 0 &&
                    results[0] == PackageManager.PERMISSION_GRANTED) {
                loadSongs();
            } else {
                Toast.makeText(this,
                        "Izin penyimpanan diperlukan untuk membaca musik",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    private void loadSongs() {

        songs.clear();

        Cursor cursor = null;

        try {
            Uri musicUri =
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;

            String[] columns = {
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST
            };

            String selection =
                    MediaStore.Audio.Media.IS_MUSIC + " != 0";

            cursor = getContentResolver().query(
                    musicUri, columns, selection, null,
                    MediaStore.Audio.Media.TITLE + " ASC");

            if (cursor != null && cursor.moveToFirst()) {

                do {
                    long id = cursor.getLong(0);
                    String title = cursor.getString(1);
                    String artist = cursor.getString(2);

                    Uri contentUri = Uri.withAppendedPath(
                            musicUri, String.valueOf(id));

                    if (title == null) title = "Tanpa judul";
                    if (artist == null) artist = "Artis tidak diketahui";

                    songs.add(new Song(title, artist, contentUri));

                } while (cursor.moveToNext());
            }

        } catch (Exception e) {
            Toast.makeText(this,
                    "Gagal membaca daftar musik",
                    Toast.LENGTH_SHORT).show();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        ArrayAdapter<Song> adapter =
                new ArrayAdapter<Song>(
                        this,
                        android.R.layout.simple_list_item_1,
                        songs) {

            @Override
            public View getView(int position,
                                View convertView,
                                android.view.ViewGroup parent) {

                TextView text = (TextView) super.getView(
                        position, convertView, parent);

                text.setTextColor(Color.WHITE);
                text.setTextSize(14);
                text.setPadding(dp(12), dp(12), dp(8), dp(12));

                return text;
            }
        };

        songList.setAdapter(adapter);

        if (songs.size() == 0) {
            Toast.makeText(this,
                    "Belum ada musik ditemukan",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void updateStatus() {
        if (music != null && statusText != null) {
            statusText.setText("Status: " + music.getStatus());
        }
    }

    private Button makeButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(12);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setBackground(round(accentColor, 12));
        return button;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private int dp(int value) {
        return (int) (value *
                getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        if (bound) {
            unbindService(connection);
            bound = false;
        }

        super.onDestroy();
    }
}
