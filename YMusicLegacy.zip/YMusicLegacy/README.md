# YMusic Legacy (starter project)

Proyek Android Java dengan `minSdk 18` (Android 4.3) dan target CPU ARMv7/32-bit.

## Fitur yang sudah disiapkan
- Memutar URL audio langsung melalui HTTP/HTTPS (`MediaPlayer`).
- Menampilkan dan memutar koleksi audio lokal melalui `MediaStore`.
- Kontrol jeda/lanjutkan.
- Service pemutaran latar belakang dengan notifikasi foreground.
- Tidak memakai AndroidX atau library native pihak ketiga.

## Batasan penting
- Ini adalah **proyek awal yang dapat dikembangkan**, bukan porting kode internal YMusic 3.9.23.
- Online streaming memerlukan URL audio langsung yang memang dapat diakses. Ini belum menyediakan katalog, pencarian lagu berbasis layanan, ekstraksi YouTube, atau pengunduhan dari layanan pihak ketiga.
- Dukungan codec/format bergantung pada decoder perangkat Android 4.3. MP3 umumnya didukung, tetapi tidak semua format.
- Pengunduhan belum dibuat.
- `MediaExtractor` belum diperlukan untuk pemutaran dasar; `MediaPlayer` menangani sumber audio. Jika kelak diperlukan demuxing atau pemrosesan, implementasi API media perlu ditambahkan dan diuji pada perangkat.
- Aplikasi perlu diuji pada perangkat/emulator Android 4.3 ARMv7. Build sukses tidak menjamin semua URL stream atau codec akan berfungsi.

## Build
1. Buka folder ini dengan Android Studio yang mendukung Android Gradle Plugin 8.6.1.
2. Gunakan JDK 17 dan pasang Android SDK Platform 35.
3. Jalankan Gradle sync.
4. Pilih Build > Build APK(s).
5. APK debug akan berada di `app/build/outputs/apk/debug/`.

Untuk perangkat Android 4.3, pastikan APK `armeabi-v7a`/universal dan uji pada perangkat fisik. Kode Java ini tidak menyertakan library native sehingga arsitektur APK tidak membatasi CPU.

## Catatan kompatibilitas
Proyek menetapkan `minSdk 18`, `targetSdk 28`. Perangkat Android 4.3 tidak memiliki runtime permission model Android 6+, sedangkan pemeriksaan izin pada kode hanya aktif pada API 23+.
