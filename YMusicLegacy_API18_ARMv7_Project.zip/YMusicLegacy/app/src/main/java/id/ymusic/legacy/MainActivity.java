package id.ymusic.legacy;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQ_STORAGE = 41;
    private MusicService music;
    private boolean bound = false;
    private TextView status;
    private EditText urlInput;
    private LinearLayout songList;
    private final ArrayList<Song> songs = new ArrayList<>();

    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            music = ((MusicService.LocalBinder) binder).getService();
            bound = true;
            status.setText(music.getStatus());
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            bound = false; music = null;
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        Intent service = new Intent(this, MusicService.class);
        startService(service);
        bindService(service, connection, Context.BIND_AUTO_CREATE);
        loadLocalSongs();
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(18), dp(16), dp(12));
        page.setBackgroundColor(0xff10131b);

        TextView title = new TextView(this);
        title.setText("YMusic Legacy");
        title.setTextColor(0xffffffff);
        title.setTextSize(25);
        title.setTypeface(null, 1);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Online audio • Musik lokal");
        subtitle.setTextColor(0xffaab3c5);
        subtitle.setTextSize(13);
        page.addView(subtitle);

        status = new TextView(this);
        status.setText("Siap memutar");
        status.setTextColor(0xff8ee6c0);
        status.setPadding(0, dp(18), 0, dp(12));
        page.addView(status);

        TextView onlineLabel = label("PUTAR AUDIO ONLINE");
        page.addView(onlineLabel);
        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setHint("https://alamat-server/audio.mp3");
        urlInput.setHintTextColor(0xff8c94a5);
        urlInput.setTextColor(0xffffffff);
        urlInput.setTextSize(14);
        urlInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        page.addView(urlInput, new LinearLayout.LayoutParams(-1, dp(48)));

        Button stream = button("Putar URL");
        page.addView(stream);
        stream.setOnClickListener(v -> {
            String value = urlInput.getText().toString().trim();
            if (!(value.startsWith("https://") || value.startsWith("http://"))) {
                toast("Masukkan URL audio HTTP/HTTPS yang langsung mengarah ke file atau stream.");
                return;
            }
            hideKeyboard();
            if (bound) music.playUrl(value);
        });

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        Button pause = button("Jeda");
        Button resume = button("Lanjutkan");
        controls.addView(pause, new LinearLayout.LayoutParams(0, dp(46), 1));
        controls.addView(resume, new LinearLayout.LayoutParams(0, dp(46), 1));
        page.addView(controls);
        pause.setOnClickListener(v -> { if (bound) music.pause(); });
        resume.setOnClickListener(v -> { if (bound) music.resume(); });

        TextView localLabel = label("MUSIK DI PERANGKAT");
        localLabel.setPadding(0, dp(20), 0, dp(8));
        page.addView(localLabel);

        Button refresh = button("Muat ulang daftar musik");
        page.addView(refresh);
        refresh.setOnClickListener(v -> loadLocalSongs());

        ScrollView scroll = new ScrollView(this);
        songList = new LinearLayout(this);
        songList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(songList);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(page);
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextColor(0xffc5cde0); t.setTextSize(12);
        t.setTypeface(null, 1); t.setPadding(0, dp(12), 0, dp(4));
        return t;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        return b;
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void loadLocalSongs() {
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_STORAGE);
            return;
        }
        songs.clear();
        songList.removeAllViews();
        Uri collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = { MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.IS_MUSIC };
        Cursor c = null;
        try {
            c = getContentResolver().query(collection, projection,
                    MediaStore.Audio.Media.IS_MUSIC + "!=0", null,
                    MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC");
            if (c != null) {
                int idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
                int titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
                int artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);
                while (c.moveToNext()) {
                    long id = c.getLong(idCol);
                    String name = c.getString(titleCol);
                    String artist = c.getString(artistCol);
                    Uri uri = Uri.withAppendedPath(collection, String.valueOf(id));
                    Song song = new Song(name == null ? "Tanpa judul" : name,
                            artist == null ? "Artis tidak diketahui" : artist, uri);
                    songs.add(song);
                }
            }
        } catch (Exception e) {
            toast("Tidak dapat membaca koleksi musik: " + e.getMessage());
        } finally {
            if (c != null) c.close();
        }

        if (songs.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Belum ada musik lokal yang ditemukan.");
            empty.setTextColor(0xffaab3c5);
            empty.setPadding(0, dp(14), 0, dp(14));
            songList.addView(empty);
        } else {
            for (Song song : songs) {
                Button item = new Button(this);
                item.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
                item.setText(song.title + "\n" + song.artist);
                item.setTextSize(12);
                songList.addView(item, new LinearLayout.LayoutParams(-1, dp(58)));
                item.setOnClickListener(v -> {
                    if (bound) music.playLocal(song.uri);
                });
            }
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_STORAGE && results.length > 0 &&
                results[0] == PackageManager.PERMISSION_GRANTED) loadLocalSongs();
        else if (requestCode == REQ_STORAGE) toast("Izin penyimpanan diperlukan untuk menampilkan MP3 lokal.");
    }

    private void hideKeyboard() {
        try {
            ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(urlInput.getWindowToken(), 0);
        } catch (Exception ignored) {}
    }

    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_LONG).show(); }

    @Override protected void onDestroy() {
        if (bound) { unbindService(connection); bound = false; }
        super.onDestroy();
    }

    private static class Song {
        final String title, artist; final Uri uri;
        Song(String t, String a, Uri u) { title=t; artist=a; uri=u; }
    }
}
