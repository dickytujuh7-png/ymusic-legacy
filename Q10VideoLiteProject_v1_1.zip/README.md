# Q10 Video Lite

Aplikasi demo pemutar video online sederhana untuk Android Runtime lama (minSdk 18 / ARMv7-friendly).

## Fitur
- Pemutaran MP4 online dengan Android `VideoView`
- Tombol putar/jeda dan video berikut/sebelumnya
- Geser layar ke atas/bawah untuk mengganti video
- Tidak memerlukan login

## Catatan penting
Ini bukan aplikasi TikTok dan tidak mengakses konten atau server TikTok. Aplikasi memuat beberapa video demonstrasi publik sebagai contoh. Pemutaran pada BlackBerry Q10 OS 10.3 belum dijamin: dukungan HTTPS, codec, TLS, dan layanan video bergantung pada Android Runtime dan firmware perangkat.

## Build
Push proyek ini ke repositori GitHub pada branch `main`. Workflow GitHub Actions akan membuat APK debug. Buka Actions, pilih build yang berhasil, lalu unduh artifact `Q10-Video-Lite-APK`.

## Versi 1.1
Tema aplikasi diubah dari Theme.Material (Android 5.0+) ke Theme.Holo.NoActionBar agar lebih sesuai dengan Android Runtime API 18 pada BlackBerry Q10 OS 10.3.
