package id.q10.videolite;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.MediaController;
import android.widget.Toast;
import android.net.Uri;

public class MainActivity extends Activity {
    private VideoView videoView;
    private TextView title;
    private int current = 0;
    private float downY;
    private boolean prepared = false;

    private final String[] names = {
        "Big Buck Bunny — video demo",
        "Sintel — video demo",
        "Tears of Steel — video demo"
    };

    // Sample progressive MP4 streams for testing. They are not TikTok content.
    private final String[] urls = {
        "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
        "https://storage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
        "https://storage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"
    };

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildScreen();
        playCurrent();
    }

    private void buildScreen() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        videoView = new VideoView(this);
        FrameLayout.LayoutParams videoParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        );
        root.addView(videoView, videoParams);

        LinearLayout overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setPadding(14, 14, 14, 14);
        overlay.setGravity(Gravity.BOTTOM);
        overlay.setBackgroundColor(Color.TRANSPARENT);

        title = new TextView(this);
        title.setTextColor(Color.WHITE);
        title.setTextSize(17);
        title.setShadowLayer(4, 1, 1, Color.BLACK);
        title.setText("Q10 VIDEO LITE");
        overlay.addView(title);

        TextView note = new TextView(this);
        note.setTextColor(Color.WHITE);
        note.setTextSize(12);
        note.setText("Video demo publik • geser atas/bawah untuk ganti");
        note.setPadding(0, 6, 0, 10);
        overlay.addView(note);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        Button previous = makeButton("SEBELUMNYA");
        Button playPause = makeButton("PUTAR / JEDA");
        Button next = makeButton("BERIKUTNYA");

        previous.setOnClickListener(v -> changeVideo(-1));
        next.setOnClickListener(v -> changeVideo(1));
        playPause.setOnClickListener(v -> {
            if (videoView.isPlaying()) videoView.pause();
            else videoView.start();
        });

        controls.addView(previous, new LinearLayout.LayoutParams(0, 48, 1));
        controls.addView(playPause, new LinearLayout.LayoutParams(0, 48, 1));
        controls.addView(next, new LinearLayout.LayoutParams(0, 48, 1));
        overlay.addView(controls);

        FrameLayout.LayoutParams overlayParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM
        );
        root.addView(overlay, overlayParams);

        videoView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                downY = event.getY();
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_UP) {
                float delta = event.getY() - downY;
                if (Math.abs(delta) > 65) {
                    changeVideo(delta < 0 ? 1 : -1);
                } else if (videoView.isPlaying()) {
                    videoView.pause();
                } else {
                    videoView.start();
                }
                return true;
            }
            return true;
        });

        setContentView(root);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(10);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(45, 45, 45));
        return b;
    }

    private void playCurrent() {
        prepared = false;
        title.setText(names[current] + "\nMemuat video...");
        try {
            videoView.setVideoURI(Uri.parse(urls[current]));
            videoView.setOnPreparedListener(mp -> {
                prepared = true;
                title.setText(names[current]);
                mp.setLooping(true);
                videoView.start();
            });
            videoView.setOnErrorListener((mp, what, extra) -> {
                title.setText(names[current] + "\nTidak dapat memutar. Periksa internet atau format video.");
                Toast.makeText(this, "Video gagal diputar pada perangkat ini.", Toast.LENGTH_LONG).show();
                return true;
            });
        } catch (Exception e) {
            title.setText("Gagal membuka video.");
        }
    }

    private void changeVideo(int direction) {
        current = (current + direction + urls.length) % urls.length;
        playCurrent();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (videoView != null && videoView.isPlaying()) videoView.pause();
    }

    @Override
    protected void onDestroy() {
        if (videoView != null) videoView.stopPlayback();
        super.onDestroy();
    }
}
